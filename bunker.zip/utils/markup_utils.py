# utils/markup_utils.py

from telebot.types import InlineKeyboardButton, InlineKeyboardMarkup

def create_voting_buttons(players):
    markup = InlineKeyboardMarkup()
    for player in players:
        button = InlineKeyboardButton(player.username, callback_data=f"vote_{player.telegram_id}")
        markup.add(button)
    return markup
