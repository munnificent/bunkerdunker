# handlers/admin_handlers.py

from database import Session
from models import Player, Room, Vote, Characteristic, Location
from utils.game_utils import (
    assign_characteristics_to_player,
    generate_location,
    get_random_event,
    get_random_ending
)
from utils.markup_utils import create_voting_buttons
from telebot.types import Message
import threading
import time

def handle_start_game(bot, message):
    session = Session()
    try:
        telegram_id = message.from_user.id
        player = session.query(Player).filter_by(telegram_id=telegram_id).first()
        if not player:
            bot.send_message(message.chat.id, "❗ Вы не зарегистрированы. Используйте /start для начала.")
            return

        room = session.query(Room).filter_by(id=player.current_room_id).first()
        if not room or room.host_id != player.id:
            bot.send_message(message.chat.id, "❗ Вы не являетесь хостом комнаты.")
            return

        if len(room.players) < 2:
            bot.send_message(message.chat.id, "❗ Недостаточно игроков для начала игры.")
            return

        # Назначаем характеристики игрокам
        for p in room.players:
            assign_characteristics_to_player(p)

        # Генерируем локацию
        location = generate_location()
        room.location_id = location.id
        session.commit()

        # Отправляем характеристики игрокам
        for p in room.players:
            characteristics = session.query(Characteristic).filter_by(player_id=p.id).first()
            char_text = f"""
    <b>Ваши характеристики:</b>
    👤 <b>Профессия:</b> {characteristics.profession}
    🧬 <b>Биология:</b> {characteristics.biology}
    ❤️ <b>Здоровье:</b> {characteristics.health}
    🎨 <b>Хобби:</b> {characteristics.hobby}
    🎒 <b>Багаж:</b> {characteristics.luggage}
    📜 <b>Факт:</b> {characteristics.facts}
    """
            bot.send_message(p.telegram_id, char_text, parse_mode='HTML')

        # Отправляем информацию о локации
        location = session.query(Location).filter_by(id=room.location_id).first()
        location_text = f"""
    <b>Описание катастрофы:</b>
    {location.description}

    <b>Условия для выживания:</b>
    {location.survival_conditions}
    """
        for p in room.players:
            bot.send_message(p.telegram_id, location_text, parse_mode='HTML')

        bot.send_message(message.chat.id, "🎮 Игра началась! Используйте /start_discussion для начала обсуждения.")
    except Exception as e:
        session.rollback()
        bot.send_message(message.chat.id, "Произошла ошибка при начале игры.")
        print(f"Ошибка в handle_start_game: {e}")
    finally:
        session.close()


def handle_kick_player(bot, message):
    session = Session()
    try:
        telegram_id = message.from_user.id
        player = session.query(Player).filter_by(telegram_id=telegram_id).first()

        if not player:
            bot.send_message(message.chat.id, "❗ Вы не зарегистрированы. Используйте /start для начала.")
            return

        room = session.query(Room).filter_by(id=player.current_room_id).first()
        if not room or room.host_id != player.id:
            bot.send_message(message.chat.id, "❗ Вы не являетесь хостом комнаты.")
            return

        try:
            username = message.text.split()[1]
        except IndexError:
            bot.send_message(message.chat.id, "❗ Пожалуйста, укажите имя пользователя для исключения.")
            return

        kicked_player = session.query(Player).filter_by(username=username).first()
        if not kicked_player or kicked_player not in room.players:
            bot.send_message(message.chat.id, "❗ Игрок не найден в комнате.")
            return

        room.players.remove(kicked_player)
        kicked_player.current_room_id = None

        # Удаляем характеристики исключенного игрока
        characteristics = session.query(Characteristic).filter_by(player_id=kicked_player.id).first()
        if characteristics:
            session.delete(characteristics)

        session.commit()

        bot.send_message(message.chat.id, f"🚫 Игрок <b>{username}</b> был исключен из комнаты.", parse_mode='HTML')
        bot.send_message(kicked_player.telegram_id, "❗ Вы были исключены из комнаты.")
    except Exception as e:
        session.rollback()
        bot.send_message(message.chat.id, "Произошла ошибка при исключении игрока.")
        print(f"Ошибка в handle_kick_player: {e}")
    finally:
        session.close()


def handle_stop_game(bot, message):
    session = Session()
    try:
        telegram_id = message.from_user.id
        player = session.query(Player).filter_by(telegram_id=telegram_id).first()

        if not player:
            bot.send_message(message.chat.id, "❗ Вы не зарегистрированы. Используйте /start для начала.")
            return

        room = session.query(Room).filter_by(id=player.current_room_id).first()
        if not room or room.host_id != player.id:
            bot.send_message(message.chat.id, "❗ Вы не являетесь хостом комнаты.")
            return

        room.is_active = False
        session.commit()

        bot.send_message(message.chat.id, "⛔ Игра завершена.")

        # Обновляем информацию для всех игроков в комнате
        for p in room.players:
            p.current_room_id = None

            # Удаляем характеристики игрока
            characteristics = session.query(Characteristic).filter_by(player_id=p.id).first()
            if characteristics:
                session.delete(characteristics)

            session.commit()
            bot.send_message(p.telegram_id, "❗ Игра была завершена хостом. Ваши характеристики сброшены.")
    except Exception as e:
        session.rollback()
        bot.send_message(message.chat.id, "Произошла ошибка при завершении игры.")
        print(f"Ошибка в handle_stop_game: {e}")
    finally:
        session.close()


def handle_start_discussion(bot, message):
    session = Session()
    try:
        telegram_id = message.from_user.id
        player = session.query(Player).filter_by(telegram_id=telegram_id).first()

        if not player:
            bot.send_message(message.chat.id, "❗ Вы не зарегистрированы. Используйте /start для начала.")
            return

        room = session.query(Room).filter_by(id=player.current_room_id).first()
        if not room or room.host_id != player.id:
            bot.send_message(message.chat.id, "❗ Вы не являетесь хостом комнаты.")
            return

        room.is_voting = False
        session.commit()

        for p in room.players:
            bot.send_message(p.telegram_id, "💬 Обсуждение началось! Вы можете обсуждать свои характеристики.")
    except Exception as e:
        session.rollback()
        bot.send_message(message.chat.id, "Произошла ошибка при начале обсуждения.")
        print(f"Ошибка в handle_start_discussion: {e}")
    finally:
        session.close()

def handle_end_discussion(bot, message):
    session = Session()
    try:
        telegram_id = message.from_user.id
        player = session.query(Player).filter_by(telegram_id=telegram_id).first()

        if not player:
            bot.send_message(message.chat.id, "❗ Вы не зарегистрированы. Используйте /start для начала.")
            return

        room = session.query(Room).filter_by(id=player.current_room_id).first()
        if not room or room.host_id != player.id:
            bot.send_message(message.chat.id, "❗ Вы не являетесь хостом комнаты.")
            return

        room.is_voting = True
        session.commit()

        for p in room.players:
            bot.send_message(p.telegram_id, "🗳️ Обсуждение завершено! Начинается голосование.")
            handle_vote_command(bot, p.telegram_id)
    except Exception as e:
        session.rollback()
        bot.send_message(message.chat.id, "Произошла ошибка при завершении обсуждения.")
        print(f"Ошибка в handle_end_discussion: {e}")
    finally:
        session.close()

def handle_vote_command(bot, chat_id):
    session = Session()
    try:
        voter = session.query(Player).filter_by(telegram_id=chat_id).first()
        if not voter:
            bot.send_message(chat_id, "❗ Вы не зарегистрированы. Используйте /start для начала.")
            return

        room = session.query(Room).filter_by(id=voter.current_room_id).first()
        if not room:
            bot.send_message(chat_id, "❗ Вы не находитесь в комнате.")
            return

        if not room.is_voting:
            bot.send_message(chat_id, "❗ Сейчас не время для голосования.")
            return

        existing_vote = session.query(Vote).filter_by(room_id=room.id, voter_id=voter.id).first()
        if existing_vote:
            bot.send_message(chat_id, "❗ Вы уже проголосовали.")
            return

        players_in_room = [p for p in room.players if p.telegram_id != voter.telegram_id]
        markup = create_voting_buttons(players_in_room)
        bot.send_message(chat_id, "🗳️ Выберите игрока для исключения:", reply_markup=markup)
    except Exception as e:
        bot.send_message(chat_id, "Произошла ошибка при начале голосования.")
        print(f"Ошибка в handle_vote_command: {e}")
    finally:
        session.close()

def handle_vote_callback(bot, call):
    session = Session()
    try:
        voter_id = call.from_user.id
        voted_player_telegram_id = int(call.data.split('_')[1])

        voter = session.query(Player).filter_by(telegram_id=voter_id).first()
        if not voter:
            bot.answer_callback_query(call.id, "❗ Вы не зарегистрированы.")
            return

        room = session.query(Room).filter_by(id=voter.current_room_id).first()
        if not room or not room.is_voting:
            bot.answer_callback_query(call.id, "❗ Сейчас не время для голосования.")
            return

        existing_vote = session.query(Vote).filter_by(room_id=room.id, voter_id=voter.id).first()
        if existing_vote:
            bot.answer_callback_query(call.id, "❗ Вы уже проголосовали!")
            return

        voted_player = session.query(Player).filter_by(telegram_id=voted_player_telegram_id).first()
        if not voted_player:
            bot.answer_callback_query(call.id, "❗ Выбранный игрок не найден.")
            return

        vote = Vote(room_id=room.id, voter_id=voter.id, voted_player_id=voted_player.id)
        session.add(vote)
        session.commit()

        bot.answer_callback_query(call.id, "✅ Ваш голос учтен!")

        total_votes = session.query(Vote).filter_by(room_id=room.id).count()
        total_players = len(room.players)

        if total_votes == total_players:
            handle_vote_results(bot, room)
    except Exception as e:
        session.rollback()
        bot.answer_callback_query(call.id, "❗ Произошла ошибка при голосовании.")
        print(f"Ошибка в handle_vote_callback: {e}")
    finally:
        session.close()

def handle_vote_results(bot, room):
    session = Session()
    try:
        votes = session.query(Vote).filter_by(room_id=room.id).all()
        vote_counts = {}
        for vote in votes:
            vote_counts[vote.voted_player_id] = vote_counts.get(vote.voted_player_id, 0) + 1

        max_votes = max(vote_counts.values())
        players_with_max_votes = [pid for pid, count in vote_counts.items() if count == max_votes]

        # Получаем объект хоста
        host = session.query(Player).filter_by(id=room.host_id).first()

        if len(players_with_max_votes) > 1:
            if host:
                bot.send_message(host.telegram_id, "⚖️ Ничья при голосовании. Необходимо переголосовать.")
            session.query(Vote).filter_by(room_id=room.id).delete()
            session.commit()
            for player in room.players:
                bot.send_message(player.telegram_id, "🗳️ Переголосование началось!")
                handle_vote_command(bot, player.telegram_id)
            return

        excluded_player_id = players_with_max_votes[0]
        excluded_player = session.query(Player).filter_by(id=excluded_player_id).first()
        room.players.remove(excluded_player)
        excluded_player.current_room_id = None

        # Удаляем характеристики исключенного игрока
        characteristics = session.query(Characteristic).filter_by(player_id=excluded_player.id).first()
        if characteristics:
            session.delete(characteristics)

        session.commit()

        for player in room.players:
            bot.send_message(player.telegram_id, f"🚫 Игрок <b>{excluded_player.username}</b> был исключен из бункера.", parse_mode='HTML')
        bot.send_message(excluded_player.telegram_id, "❗ Вы были исключены из бункера.")

        # Отправляем характеристики исключенного игрока остальным
        characteristics_text = f"""
<b>Характеристики исключенного игрока {excluded_player.username}:</b>
👤 <b>Профессия:</b> {characteristics.profession}
🧬 <b>Биология:</b> {characteristics.biology}
❤️ <b>Здоровье:</b> {characteristics.health}
🎨 <b>Хобби:</b> {characteristics.hobby}
🎒 <b>Багаж:</b> {characteristics.luggage}
📜 <b>Факты:</b> {characteristics.facts}
"""
        for player in room.players:
            bot.send_message(player.telegram_id, characteristics_text, parse_mode='HTML')

        session.query(Vote).filter_by(room_id=room.id).delete()
        session.commit()

        if len(room.players) <= room.survivors:
            end_game(bot, room)
        else:
            trigger_random_event(bot, room)
            if host:
                bot.send_message(host.telegram_id, "💬 Используйте /start_discussion для начала следующего раунда обсуждения.")
    except Exception as e:
        session.rollback()
        if host:
            bot.send_message(host.telegram_id, "Произошла ошибка при обработке результатов голосования.")
        print(f"Ошибка в handle_vote_results: {e}")
    finally:
        session.close()


def end_game(bot, room):
    session = Session()
    try:
        survivors_needed = room.survivors
        if len(room.players) <= survivors_needed:
            winner_usernames = [player.username for player in room.players]
            winners_text = "🎉 <b>Игра завершена!</b>\n\n<b>Выжившие игроки:</b>\n" + "\n".join(winner_usernames)
            for player in room.players:
                bot.send_message(player.telegram_id, winners_text, parse_mode='HTML')
                player.wins += 1
                player.current_room_id = None

                # Удаляем характеристики игрока
                characteristics = session.query(Characteristic).filter_by(player_id=player.id).first()
                if characteristics:
                    session.delete(characteristics)

                session.commit()

            excluded_players = session.query(Player).filter(Player.current_room_id == room.id).all()
            for player in excluded_players:
                player.losses += 1
                player.current_room_id = None

                # Удаляем характеристики игрока
                characteristics = session.query(Characteristic).filter_by(player_id=player.id).first()
                if characteristics:
                    session.delete(characteristics)

                session.commit()

            room.is_active = False
            session.commit()

            # Добавляем вывод случайной концовки
            ending = get_random_ending()
            for player in room.players:
                bot.send_message(player.telegram_id, f"🏁 <b>Концовка игры:</b>\n{ending}", parse_mode='HTML')

    except Exception as e:
        session.rollback()
        host = session.query(Player).filter_by(id=room.host_id).first()
        if host:
            bot.send_message(host.telegram_id, "Произошла ошибка при завершении игры.")
        print(f"Ошибка в end_game: {e}")
    finally:
        session.close()




def trigger_random_event(bot, room):
    event = get_random_event()
    for player in room.players:
        bot.send_message(player.telegram_id, f"🔔 <b>Случайное событие:</b>\n{event}", parse_mode='HTML')

def handle_timer(bot, message):
    try:
        telegram_id = message.from_user.id
        try:
            minutes = int(message.text.split()[1])
        except (IndexError, ValueError):
            bot.send_message(message.chat.id, "❗ Пожалуйста, укажите время в минутах после команды.")
            return

        bot.send_message(message.chat.id, f"⏳ Таймер запущен на {minutes} минут.")
        threading.Thread(target=timer_thread, args=(bot, message.chat.id, minutes)).start()
    except Exception as e:
        bot.send_message(message.chat.id, "Произошла ошибка при запуске таймера.")
        print(f"Ошибка в handle_timer: {e}")

def timer_thread(bot, chat_id, minutes):
    time.sleep(minutes * 60)
    bot.send_message(chat_id, "⏰ Время вышло!")
