# handlers/game_handlers.py

from database import Session
from models import Player, Room, Characteristic, Vote, Location
from utils.game_utils import (
    get_random_event
)
from utils.markup_utils import create_voting_buttons
from telebot.types import Message

def handle_show_status(bot, message):
    session = Session()
    try:
        telegram_id = message.from_user.id
        player = session.query(Player).filter_by(telegram_id=telegram_id).first()
        if not player:
            bot.send_message(message.chat.id, "❗ Вы не зарегистрированы. Используйте /start для начала.")
            return

        characteristics = session.query(Characteristic).filter_by(player_id=player.id).first()
        if not characteristics:
            bot.send_message(message.chat.id, "❗ У вас нет характеристик.")
            return

        char_text = f"""
<b>Ваши характеристики:</b>
👤 <b>Профессия:</b> {characteristics.profession}
🧬 <b>Биология:</b> {characteristics.biology}
❤️ <b>Здоровье:</b> {characteristics.health}
🎨 <b>Хобби:</b> {characteristics.hobby}
🎒 <b>Багаж:</b> {characteristics.luggage}
📜 <b>Факты:</b> {characteristics.facts}
"""
        bot.send_message(message.chat.id, char_text, parse_mode='HTML')
    except Exception as e:
        bot.send_message(message.chat.id, "Произошла ошибка при получении ваших характеристик.")
        print(f"Ошибка в handle_show_status: {e}")
    finally:
        session.close()

def handle_leave_room(bot, message):
    session = Session()
    try:
        telegram_id = message.from_user.id
        player = session.query(Player).filter_by(telegram_id=telegram_id).first()

        if not player or not player.current_room_id:
            bot.send_message(message.chat.id, "❗ Вы не находитесь в комнате.")
            return

        room = session.query(Room).filter_by(id=player.current_room_id).first()
        room.players.remove(player)
        player.current_room_id = None

        # Удаляем характеристики игрока
        characteristics = session.query(Characteristic).filter_by(player_id=player.id).first()
        if characteristics:
            session.delete(characteristics)

        session.commit()

        bot.send_message(message.chat.id, "🚪 Вы покинули комнату.")
        for p in room.players:
            bot.send_message(p.telegram_id, f"👤 Игрок <b>{player.username}</b> покинул комнату.", parse_mode='HTML')
    except Exception as e:
        session.rollback()
        bot.send_message(message.chat.id, "Произошла ошибка при выходе из комнаты.")
        print(f"Ошибка в handle_leave_room: {e}")
    finally:
        session.close()


def handle_rating(bot, message):
    session = Session()
    try:
        telegram_id = message.from_user.id
        player = session.query(Player).filter_by(telegram_id=telegram_id).first()
        if not player:
            bot.send_message(message.chat.id, "❗ Вы не зарегистрированы. Используйте /start для начала.")
            return
        rating_text = f"""
<b>Ваш рейтинг:</b>
🏆 <b>Побед:</b> {player.wins}
💀 <b>Поражений:</b> {player.losses}
"""
        bot.send_message(message.chat.id, rating_text, parse_mode='HTML')
    except Exception as e:
        bot.send_message(message.chat.id, "Произошла ошибка при получении вашего рейтинга.")
        print(f"Ошибка в handle_rating: {e}")
    finally:
        session.close()
