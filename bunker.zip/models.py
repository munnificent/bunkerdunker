# models.py

from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey, Boolean, Text, Table
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, ForeignKey, Boolean, Text, Table
from sqlalchemy.orm import relationship

Base = declarative_base()

Base = declarative_base()

# Ассоциация между комнатами и игроками
room_player_association = Table('room_player', Base.metadata,
    Column('room_id', Integer, ForeignKey('rooms.id')),
    Column('player_id', Integer, ForeignKey('players.id'))
)

class Player(Base):
    __tablename__ = 'players'
    id = Column(Integer, primary_key=True)
    telegram_id = Column(Integer, unique=True)
    username = Column(String)
    wins = Column(Integer, default=0)
    losses = Column(Integer, default=0)
    current_room_id = Column(Integer, ForeignKey('rooms.id'))
    characteristics = relationship("Characteristic", back_populates="player")

class Room(Base):
    __tablename__ = 'rooms'
    id = Column(Integer, primary_key=True)
    code = Column(String, unique=True)
    host_id = Column(Integer, ForeignKey('players.id'))
    is_active = Column(Boolean, default=True)
    is_voting = Column(Boolean, default=False)
    max_players = Column(Integer)
    survivors = Column(Integer)
    players = relationship("Player", secondary=room_player_association)
    location_id = Column(Integer, ForeignKey('locations.id'))
    votes = relationship("Vote", back_populates="room")

class Characteristic(Base):
    __tablename__ = 'characteristics'
    id = Column(Integer, primary_key=True)
    player_id = Column(Integer, ForeignKey('players.id'))
    profession = Column(String)
    biology = Column(String)
    health = Column(String)
    hobby = Column(String)
    luggage = Column(String)
    facts = Column(String)
    player = relationship("Player", back_populates="characteristics")

class Location(Base):
    __tablename__ = 'locations'
    id = Column(Integer, primary_key=True)
    description = Column(Text)
    survival_conditions = Column(Text)

class Vote(Base):
    __tablename__ = 'votes'
    id = Column(Integer, primary_key=True)
    room_id = Column(Integer, ForeignKey('rooms.id'))
    voter_id = Column(Integer, ForeignKey('players.id'))
    voted_player_id = Column(Integer, ForeignKey('players.id'))
    room = relationship("Room", back_populates="votes")

class Profession(Base):
    __tablename__ = 'professions'
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)

class Biology(Base):
    __tablename__ = 'biology'
    id = Column(Integer, primary_key=True)
    gender = Column(String, nullable=False)
    age = Column(Integer, nullable=False)
    body_features = Column(String, nullable=False)

class Health(Base):
    __tablename__ = 'health'
    id = Column(Integer, primary_key=True)
    condition = Column(String, nullable=False)

class Hobby(Base):
    __tablename__ = 'hobbies'
    id = Column(Integer, primary_key=True)
    hobby = Column(String, nullable=False)

class Luggage(Base):
    __tablename__ = 'luggage'
    id = Column(Integer, primary_key=True)
    item = Column(String, nullable=False)

class Fact(Base):
    __tablename__ = 'facts'
    id = Column(Integer, primary_key=True)
    fact = Column(String, nullable=False)