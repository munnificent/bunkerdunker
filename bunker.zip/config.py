# config.py

TOKEN = '7848638232:AAGYX67TclEZvVXj_p5oAwi3oUCzoTyOtrc'  # Замените на токен вашего бота
DATABASE_NAME = 'bunker_game.db'

# Настройки игры
DEFAULT_MAX_PLAYERS = 15
DEFAULT_SURVIVORS = 2
