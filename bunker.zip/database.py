# database.py

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, scoped_session
from models import Base
from config import DATABASE_NAME

# Создание двигателя базы данных
engine = create_engine(f'sqlite:///{DATABASE_NAME}', connect_args={'check_same_thread': False})

# Создание фабрики сессий
SessionFactory = sessionmaker(bind=engine)

# Создание потокобезопасной сессии
Session = scoped_session(SessionFactory)

def init_db():
    Base.metadata.create_all(engine)
